package com.mockgps.gpx;

import android.os.Bundle;
import android.util.Log;
import androidx.appcompat.app.AppCompatActivity;

public class SplashActivity extends AppCompatActivity {
    
    private static final String TAG = "MockGPS_Debug";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "App iniciándose...");
        
        try {
            // Intentar cargar la actividad principal
            startActivity(new Intent(this, MainActivity.class));
            finish();
        } catch (Exception e) {
            Log.e(TAG, "Error al iniciar MainActivity: " + e.getMessage());
            e.printStackTrace();
            // Mostrar mensaje de error simple
            setContentView(android.R.layout.simple_list_item_1);
            TextView tv = findViewById(android.R.id.text1);
            tv.setText("Error: " + e.getMessage());
        }
    }
}