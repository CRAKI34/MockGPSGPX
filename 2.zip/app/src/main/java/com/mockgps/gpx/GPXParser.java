package com.mockgps.gpx;

import android.content.Context;

import org.w3c.dom.*;
import javax.xml.parsers.*;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class GPXParser {

    public static List<double[]> parse(Context ctx, InputStream is) {
        List<double[]> points = new ArrayList<>();

        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(is);

            NodeList nodes = doc.getElementsByTagName("trkpt");

            for (int i = 0; i < nodes.getLength(); i++) {
                Element e = (Element) nodes.item(i);
                double lat = Double.parseDouble(e.getAttribute("lat"));
                double lon = Double.parseDouble(e.getAttribute("lon"));
                points.add(new double[]{lat, lon});
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return points;
    }
}