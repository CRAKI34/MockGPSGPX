package com.mockgps.gpx;

import org.xmlpull.v1.XmlPullParser;
import android.content.Context;
import android.util.Xml;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class GPXParser {

    public static List<double[]> parse(Context c, InputStream in)
            throws Exception {

        List<double[]> pts = new ArrayList<>();
        XmlPullParser p = Xml.newPullParser();
        p.setInput(in, null);

        int e = p.getEventType();
        while (e != XmlPullParser.END_DOCUMENT) {
            if (e == XmlPullParser.START_TAG &&
                    p.getName().equals("trkpt")) {
                double lat = Double.parseDouble(
                        p.getAttributeValue(null,"lat"));
                double lon = Double.parseDouble(
                        p.getAttributeValue(null,"lon"));
                pts.add(new double[]{lat, lon});
            }
            e = p.next();
        }
        return pts;
    }
}