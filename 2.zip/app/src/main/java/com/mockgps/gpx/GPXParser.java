package com.mockgps.gpx;

import android.content.Context;
import android.net.Uri;
import org.xmlpull.v1.*;
import java.io.InputStream;
import java.util.*;

public class GPXParser {

    public static List<double[]> parse(Context c, Uri uri) {
        List<double[]> pts = new ArrayList<>();
        try {
            InputStream is = c.getContentResolver().openInputStream(uri);
            XmlPullParser p = XmlPullParserFactory.newInstance().newPullParser();
            p.setInput(is, null);

            while (p.next() != XmlPullParser.END_DOCUMENT) {
                if (p.getEventType() == XmlPullParser.START_TAG &&
                        p.getName().equals("trkpt")) {
                    pts.add(new double[]{
                            Double.parseDouble(p.getAttributeValue(null, "lat")),
                            Double.parseDouble(p.getAttributeValue(null, "lon"))
                    });
                }
            }
        } catch (Exception ignored) {}
        return pts;
    }
}