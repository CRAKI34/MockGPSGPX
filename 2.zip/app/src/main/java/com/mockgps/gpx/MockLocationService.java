package com.mockgps.gpx;

import android.app.*;
import android.content.Intent;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.os.IBinder;
import androidx.annotation.Nullable;

public class MockLocationService extends Service {

    private LocationManager lm;
    private boolean running = true;

    @Override
    public void onCreate() {
        super.onCreate();

        lm = (LocationManager) getSystemService(LOCATION_SERVICE);

        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(
                    "mockgps",
                    "Mock GPS",
                    NotificationManager.IMPORTANCE_LOW
            );
            getSystemService(NotificationManager.class)
                    .createNotificationChannel(ch);

            Notification n = new Notification.Builder(this, "mockgps")
                    .setContentTitle("Mock GPS activo")
                    .setContentText("Simulando ubicación")
                    .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                    .build();

            startForeground(1, n);
        }

        try {
            lm.addTestProvider(
                    LocationManager.GPS_PROVIDER,
                    false,false,false,false,
                    true,true,true,0,5
            );
        } catch (Exception ignored) {}

        lm.setTestProviderEnabled(LocationManager.GPS_PROVIDER, true);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        double lat = intent.getDoubleExtra("lat", 0);
        double lon = intent.getDoubleExtra("lon", 0);

        new Thread(() -> {
            while (running) {
                Location loc = new Location(LocationManager.GPS_PROVIDER);
                loc.setLatitude(lat);
                loc.setLongitude(lon);
                loc.setAccuracy(1);
                loc.setTime(System.currentTimeMillis());
                if (Build.VERSION.SDK_INT >= 17)
                    loc.setElapsedRealtimeNanos(System.nanoTime());

                lm.setTestProviderLocation(
                        LocationManager.GPS_PROVIDER, loc);

                try { Thread.sleep(1000); }
                catch (InterruptedException ignored) {}
            }
        }).start();

        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        running = false;
        try {
            lm.removeTestProvider(LocationManager.GPS_PROVIDER);
        } catch (Exception ignored) {}
        super.onDestroy();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}