package com.mockgps.gpx;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;

import androidx.core.app.NotificationCompat;

import java.util.List;

public class MockLocationService extends Service {

    private LocationManager lm;
    private boolean running = true;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        startForeground(1, createNotification());

        lm = (LocationManager) getSystemService(LOCATION_SERVICE);

        try {
            lm.addTestProvider(LocationManager.GPS_PROVIDER,
                    false,false,false,false,true,true,true,0,5);
        } catch (Exception ignored) {}

        lm.setTestProviderEnabled(LocationManager.GPS_PROVIDER, true);

        String mode = intent.getStringExtra("mode");

        new Thread(() -> {
            try {
                if ("fixed".equals(mode)) {
                    send(intent.getDoubleExtra("lat",0),
                         intent.getDoubleExtra("lon",0));
                } else {
                    List<double[]> pts = GPXParser.parse(this,
                            Uri.parse(intent.getStringExtra("gpx")));
                    for (double[] p : pts) {
                        if (!running) break;
                        send(p[0], p[1]);
                        Thread.sleep(1000); // caminar
                    }
                }
            } catch (Exception ignored) {}
        }).start();

        return START_STICKY;
    }

    private void send(double lat, double lon) {
        Location l = new Location(LocationManager.GPS_PROVIDER);
        l.setLatitude(lat);
        l.setLongitude(lon);
        l.setAccuracy(1f);
        l.setTime(System.currentTimeMillis());
        lm.setTestProviderLocation(LocationManager.GPS_PROVIDER, l);
    }

    private Notification createNotification() {
        String ch = "mockgps";
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(
                    ch, "Mock GPS", NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(c);
        }
        return new NotificationCompat.Builder(this, ch)
                .setContentTitle("Mock GPS activo")
                .setContentText("Simulando ubicación")
                .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                .build();
    }

    @Override
    public void onDestroy() {
        running = false;
        try { lm.removeTestProvider(LocationManager.GPS_PROVIDER); }
        catch (Exception ignored) {}
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}