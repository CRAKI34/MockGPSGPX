package com.mockgps.gpx;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.os.SystemClock;
import android.widget.Toast;
import androidx.core.app.NotificationCompat;
import java.util.List;

public class MockLocationService extends Service {

    private LocationManager lm;
    private boolean running = true;
    private static final String CHANNEL_ID = "mock_gps_channel";

    @Override
    public int onStartCommand(Intent i, int flags, int startId) {
        // 1. Crear el canal antes de mostrar la notificación (Crucial para que no crashee)
        createNotificationChannel();
        startForeground(1, notification());

        lm = (LocationManager) getSystemService(LOCATION_SERVICE);

        try {
            // 2. Bloque try-catch para evitar cierre si no se activó la opción de desarrollador
            lm.addTestProvider(LocationManager.GPS_PROVIDER,
                    false, false, false, false, true, true, true, 0, 5);
            lm.setTestProviderEnabled(LocationManager.GPS_PROVIDER, true);

            if (i != null && "fixed".equals(i.getStringExtra("mode"))) {
                mock(i.getDoubleExtra("lat", 0),
                     i.getDoubleExtra("lon", 0));
            } else if (i != null) {
                double speedKmh = i.getDoubleExtra("speed", 30);
                String gpxPath = i.getStringExtra("gpx");
                if (gpxPath != null) {
                    new Thread(() -> playGpx(gpxPath, speedKmh)).start();
                }
            }
        } catch (SecurityException | IllegalArgumentException e) {
            // Si el usuario no activó la app en "Ubicación de prueba", entra aquí.
            Toast.makeText(this, "ERROR: Activa 'Ubicación de prueba' en Opciones de Desarrollador", Toast.LENGTH_LONG).show();
            stopSelf(); // Detener servicio limpiamente
            return START_NOT_STICKY;
        }

        return START_STICKY;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Mock GPS Service",
                    NotificationManager.IMPORTANCE_LOW
            );
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }

    private void playGpx(String gpx, double speedKmh) {
        List<double[]> pts = GPXParser.parse(this, Uri.parse(gpx));
        if (pts.isEmpty()) return; // Prevenir errores si el GPX está vacío
        
        double speedMs = speedKmh / 3.6;

        for (int x = 0; x < pts.size() - 1 && running; x++) {
            double[] a = pts.get(x);
            double[] b = pts.get(x + 1);

            float[] res = new float[1];
            Location.distanceBetween(a[0], a[1], b[0], b[1], res);

            // Evitar división por cero
            if (speedMs <= 0) speedMs = 1;
            
            long delay = (long) ((res[0] / speedMs) * 1000);
            if (delay < 500) delay = 500;

            mock(a[0], a[1]);

            try { Thread.sleep(delay); }
            catch (Exception ignored) {}
        }
    }

    private void mock(double lat, double lon) {
        try {
            Location l = new Location(LocationManager.GPS_PROVIDER);
            l.setLatitude(lat);
            l.setLongitude(lon);
            l.setAccuracy(1.0f);
            l.setTime(System.currentTimeMillis());
            l.setElapsedRealtimeNanos(SystemClock.elapsedRealtimeNanos());
            // Compatibilidad con APIs nuevas
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                l.setBearingAccuracyDegrees(0.1f);
                l.setVerticalAccuracyMeters(0.1f);
                l.setSpeedAccuracyMetersPerSecond(0.1f);
            }
            lm.setTestProviderLocation(LocationManager.GPS_PROVIDER, l);
        } catch (Exception ignored) {
            // Ignorar errores si el servicio se detuvo de golpe
        }
    }

    @Override
    public void onDestroy() {
        running = false;
        if (lm != null) {
            try {
                lm.removeTestProvider(LocationManager.GPS_PROVIDER);
            } catch (Exception ignored) {}
        }
        super.onDestroy();
    }

    private Notification notification() {
        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Mock GPS activo")
                .setContentText("Simulando ubicación...")
                .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}