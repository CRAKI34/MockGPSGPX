package com.mockgps.gpx;

import android.app.*;
import android.content.Intent;
import android.location.*;
import android.os.IBinder;
import androidx.core.app.NotificationCompat;

public class MockLocationService extends Service {

    LocationManager lm;

    @Override
    public void onCreate() {
        super.onCreate();

        lm = (LocationManager) getSystemService(LOCATION_SERVICE);

        Notification n = new NotificationCompat.Builder(this, "mock")
                .setContentTitle("Mock GPS activo")
                .setContentText("Simulando ubicación")
                .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                .build();

        startForeground(1, n);
    }

    @Override
    public int onStartCommand(Intent i, int f, int id) {
        if (i == null) return START_NOT_STICKY;

        try {
            lm.addTestProvider(
                LocationManager.NETWORK_PROVIDER,
                false,false,false,false,true,true,true,0,5
            );
        } catch (Exception ignored) {}

        lm.setTestProviderEnabled(LocationManager.NETWORK_PROVIDER, true);

        Location l = new Location(LocationManager.NETWORK_PROVIDER);
        l.setLatitude(i.getDoubleExtra("lat", 0));
        l.setLongitude(i.getDoubleExtra("lon", 0));
        l.setAccuracy(3);

        lm.setTestProviderLocation(LocationManager.NETWORK_PROVIDER, l);

        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent i) { return null; }
}