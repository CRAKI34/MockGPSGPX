package com.mockgps.gpx;

import android.app.*;
import android.content.*;
import android.location.*;
import android.net.Uri;
import android.os.*;
import androidx.core.app.NotificationCompat;
import java.util.List;

public class MockLocationService extends Service {

    private LocationManager lm;
    private boolean running = true;

    @Override
    public int onStartCommand(Intent i, int flags, int startId) {
        startForeground(1, notification());

        lm = (LocationManager) getSystemService(LOCATION_SERVICE);
        lm.addTestProvider(LocationManager.GPS_PROVIDER,
                false,false,false,false,true,true,true,0,5);
        lm.setTestProviderEnabled(LocationManager.GPS_PROVIDER, true);

        if ("fixed".equals(i.getStringExtra("mode"))) {
            mock(i.getDoubleExtra("lat", 0),
                 i.getDoubleExtra("lon", 0));
        } else {
            double speedKmh = i.getDoubleExtra("speed", 30);
            new Thread(() -> playGpx(i.getStringExtra("gpx"), speedKmh)).start();
        }
        return START_STICKY;
    }

    private void playGpx(String gpx, double speedKmh) {
        List<double[]> pts = GPXParser.parse(this, Uri.parse(gpx));
        double speedMs = speedKmh / 3.6;

        for (int x = 0; x < pts.size() - 1 && running; x++) {
            double[] a = pts.get(x);
            double[] b = pts.get(x + 1);

            float[] res = new float[1];
            Location.distanceBetween(a[0], a[1], b[0], b[1], res);

            long delay = (long) ((res[0] / speedMs) * 1000);
            if (delay < 500) delay = 500;

            mock(a[0], a[1]);

            try { Thread.sleep(delay); }
            catch (Exception ignored) {}
        }
    }

    private void mock(double lat, double lon) {
        Location l = new Location(LocationManager.GPS_PROVIDER);
        l.setLatitude(lat);
        l.setLongitude(lon);
        l.setAccuracy(1);
        l.setTime(System.currentTimeMillis());
        l.setElapsedRealtimeNanos(SystemClock.elapsedRealtimeNanos());
        lm.setTestProviderLocation(LocationManager.GPS_PROVIDER, l);
    }

    @Override
    public void onDestroy() {
        running = false;
        lm.removeTestProvider(LocationManager.GPS_PROVIDER);
    }

    private Notification notification() {
        return new NotificationCompat.Builder(this, "mock")
                .setContentTitle("Mock GPS activo")
                .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                .build();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}