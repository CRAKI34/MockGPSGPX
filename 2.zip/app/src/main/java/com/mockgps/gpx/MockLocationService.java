package com.mockgps.gpx;

import android.app.*;
import android.content.Intent;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.*;
import androidx.core.app.NotificationCompat;
import java.util.List;

public class MockLocationService extends Service {
    private LocationManager lm;
    private boolean running = true;
    private static final String CHANNEL_ID = "GPX_CHANNEL";

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel serviceChannel = new NotificationChannel(
                    CHANNEL_ID, "Servicio Mock GPS", NotificationManager.IMPORTANCE_LOW);
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(serviceChannel);
        }
    }

    @Override
    public int onStartCommand(Intent i, int flags, int startId) {
        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Mock GPS")
                .setContentText("Simulando ubicación...")
                .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                .build();

        startForeground(1, notification);

        lm = (LocationManager) getSystemService(LOCATION_SERVICE);
        try {
            lm.addTestProvider(LocationManager.GPS_PROVIDER, false, false, false, false, true, true, true, 0, 5);
            lm.setTestProviderEnabled(LocationManager.GPS_PROVIDER, true);
        } catch (Exception e) {
            // Si falla aquí, es porque no activaste la app en "Ubicación de prueba" en ajustes de desarrollador
        }

        if (i != null && "fixed".equals(i.getStringExtra("mode"))) {
            updateLocation(i.getDoubleExtra("lat", 0), i.getDoubleExtra("lon", 0));
        }
        
        return START_STICKY;
    }

    private void updateLocation(double lat, double lon) {
        Location l = new Location(LocationManager.GPS_PROVIDER);
        l.setLatitude(lat);
        l.setLongitude(lon);
        l.setAccuracy(1.0f);
        l.setTime(System.currentTimeMillis());
        l.setElapsedRealtimeNanos(SystemClock.elapsedRealtimeNanos());
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            l.setBearingAccuracyDegrees(0.1f);
            l.setVerticalAccuracyMeters(0.1f);
            l.setSpeedAccuracyMetersPerSecond(0.1f);
        }
        try {
            lm.setTestProviderLocation(LocationManager.GPS_PROVIDER, l);
        } catch (Exception ignored) {}
    }

    @Override
    public void onDestroy() {
        running = false;
        try {
            lm.removeTestProvider(LocationManager.GPS_PROVIDER);
        } catch (Exception ignored) {}
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}