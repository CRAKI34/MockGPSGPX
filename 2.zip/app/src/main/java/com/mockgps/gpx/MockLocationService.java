package com.mockgps.gpx;

import android.app.Service;
import android.content.Intent;
import android.location.Location;
import android.location.LocationManager;
import android.os.IBinder;

public class MockLocationService extends Service {

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        try {
            LocationManager lm = (LocationManager) getSystemService(LOCATION_SERVICE);

            lm.addTestProvider(
                    LocationManager.GPS_PROVIDER,
                    false, false, false, false,
                    true, true, true, 0, 5
            );

            lm.setTestProviderEnabled(LocationManager.GPS_PROVIDER, true);

            Location loc = new Location(LocationManager.GPS_PROVIDER);
            loc.setLatitude(19.4326);   // CDMX ejemplo
            loc.setLongitude(-99.1332);
            loc.setAccuracy(1f);
            loc.setTime(System.currentTimeMillis());

            lm.setTestProviderLocation(LocationManager.GPS_PROVIDER, loc);

        } catch (Exception e) {
            e.printStackTrace();
        }

        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}