package com.mockgps.gpx;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    private static final int REQ_GPX = 1001;
    private static final int REQ_PERMISSIONS = 1002;
    private Uri gpxUri;
    private TextView status;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        status = findViewById(R.id.statusText);
        
        // Configurar listeners primero
        setupListeners();
        
        // Verificar permisos después de que la UI esté lista
        if (hasPermissions()) {
            initializeApp();
        } else {
            requestPermissions();
        }
    }

    private void setupListeners() {
        findViewById(R.id.btnSetFixed).setOnClickListener(v -> {
            if (hasPermissions()) {
                startMockService("fixed", null);
            } else {
                requestPermissions();
            }
        });

        findViewById(R.id.btnSelectGPX).setOnClickListener(v -> {
            if (hasPermissions()) {
                selectGPXFile();
            } else {
                requestPermissions();
            }
        });

        findViewById(R.id.btnStartGPX).setOnClickListener(v -> {
            if (gpxUri != null) {
                startMockService("gpx", gpxUri.toString());
            } else {
                Toast.makeText(this, "Selecciona un GPX primero", Toast.LENGTH_SHORT).show();
            }
        });

        findViewById(R.id.btnStop).setOnClickListener(v -> {
            stopService(new Intent(this, MockLocationService.class));
            status.setText("Servicio detenido");
        });
    }

    private boolean hasPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            return ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED &&
                   ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED &&
                   ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
        } else {
            return ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED &&
                   ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED &&
                   ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
        }
    }

    private void requestPermissions() {
        String[] permissions;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions = new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION,
                    Manifest.permission.POST_NOTIFICATIONS
            };
        } else {
            permissions = new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION,
                    Manifest.permission.READ_EXTERNAL_STORAGE
            };
        }
        ActivityCompat.requestPermissions(this, permissions, REQ_PERMISSIONS);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_PERMISSIONS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                initializeApp();
            } else {
                Toast.makeText(this, "Permisos necesarios para usar la app", Toast.LENGTH_LONG).show();
                finish(); // Cerrar app si no hay permisos
            }
        }
    }

    private void initializeApp() {
        status.setText("App lista para usar");
        Toast.makeText(this, "Permisos concedidos", Toast.LENGTH_SHORT).show();
    }

    private void selectGPXFile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, REQ_GPX);
    }

    private void startMockService(String mode, String uri) {
        Intent i = new Intent(this, MockLocationService.class);
        i.putExtra("mode", mode);
        if (uri != null) i.putExtra("gpx", uri);
        
        EditText lat = findViewById(R.id.latInput);
        EditText lon = findViewById(R.id.lonInput);
        
        try {
            if (mode.equals("fixed")) {
                i.putExtra("lat", Double.parseDouble(lat.getText().toString()));
                i.putExtra("lon", Double.parseDouble(lon.getText().toString()));
            }
            ContextCompat.startForegroundService(this, i);
            status.setText("Servicio iniciado: " + mode);
        } catch (Exception e) {
            Toast.makeText(this, "Error: Revisa los datos", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int r, int c, Intent d) {
        super.onActivityResult(r, c, d);
        if (r == REQ_GPX && d != null) {
            gpxUri = d.getData();
            status.setText("GPX cargado: " + gpxUri.getLastPathSegment());
        }
    }
}