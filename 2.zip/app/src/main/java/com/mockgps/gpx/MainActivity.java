package com.mockgps.gpx;

import android.content.*;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText lat, lon, speed;
    Button startFixed, stopMock, startGpx;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        lat = findViewById(R.id.lat);
        lon = findViewById(R.id.lon);
        speed = findViewById(R.id.speed);

        startFixed = findViewById(R.id.startFixed);
        stopMock = findViewById(R.id.stopMock);
        startGpx = findViewById(R.id.startGpx);

        startFixed.setOnClickListener(v -> {
            Intent i = new Intent(this, MockLocationService.class);
            i.putExtra("mode", "fixed");
            i.putExtra("lat", Double.parseDouble(lat.getText().toString()));
            i.putExtra("lon", Double.parseDouble(lon.getText().toString()));
            startService(i);
        });

        startGpx.setOnClickListener(v -> {
            Intent i = new Intent(this, MockLocationService.class);
            i.putExtra("mode", "gpx");
            i.putExtra("speed", Float.parseFloat(speed.getText().toString()));
            startService(i);
        });

        stopMock.setOnClickListener(v -> {
            stopService(new Intent(this, MockLocationService.class));
        });
    }
}