package com.mockgps.gpx;

import android.Manifest;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class MainActivity extends AppCompatActivity {

    private static final int REQ_GPX = 1001;
    private Uri gpxUri;
    private TextView status;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        ActivityCompat.requestPermissions(this,
                new String[]{
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_BACKGROUND_LOCATION
                }, 1);

        EditText lat = findViewById(R.id.latInput);
        EditText lon = findViewById(R.id.lonInput);
        EditText speed = findViewById(R.id.speedInput);
        status = findViewById(R.id.statusText);

        findViewById(R.id.btnSetFixed).setOnClickListener(v -> {
            Intent i = new Intent(this, MockLocationService.class);
            i.putExtra("mode", "fixed");
            i.putExtra("lat", Double.parseDouble(lat.getText().toString()));
            i.putExtra("lon", Double.parseDouble(lon.getText().toString()));
            startForegroundService(i);
            status.setText("Mock GPS fijo activo");
        });

        findViewById(R.id.btnSelectGPX).setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.setType("*/*");
            startActivityForResult(i, REQ_GPX);
        });

        findViewById(R.id.btnStartGPX).setOnClickListener(v -> {
            if (gpxUri == null) return;

            double spd = 30; // default 30 km/h
            if (!speed.getText().toString().isEmpty())
                spd = Double.parseDouble(speed.getText().toString());

            Intent i = new Intent(this, MockLocationService.class);
            i.putExtra("mode", "gpx");
            i.putExtra("gpx", gpxUri.toString());
            i.putExtra("speed", spd);
            startForegroundService(i);

            status.setText("Ruta GPX activa (" + spd + " km/h)");
        });

        findViewById(R.id.btnStop).setOnClickListener(v -> {
            stopService(new Intent(this, MockLocationService.class));
            status.setText("Mock desactivado");
        });
    }

    @Override
    protected void onActivityResult(int r, int c, Intent d) {
        super.onActivityResult(r, c, d);
        if (r == REQ_GPX && d != null) gpxUri = d.getData();
    }
}