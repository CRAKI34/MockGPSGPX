package com.mockgps.gpx;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {
    
    private TextView statusText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // Primero verificar si hay crash en setContentView
        try {
            setContentView(R.layout.activity_main);
            Toast.makeText(this, "App cargada", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Error en layout: " + e.getMessage(), Toast.LENGTH_LONG).show();
            return;
        }
        
        statusText = findViewById(R.id.statusText);
        statusText.setText("App iniciada");
        
        // Configurar botones básicos
        Button btnStop = findViewById(R.id.btnStop);
        if (btnStop != null) {
            btnStop.setOnClickListener(v -> {
                Toast.makeText(MainActivity.this, "Deteniendo servicio...", Toast.LENGTH_SHORT).show();
                statusText.setText("Servicio detenido");
            });
        }
        
        // Pedir permisos después de que la UI esté lista
        requestPermissionsDelayed();
    }
    
    private void requestPermissionsDelayed() {
        // Esperar 500ms para que la UI esté estable
        new android.os.Handler().postDelayed(() -> {
            if (ContextCompat.checkSelfPermission(this, 
                Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                
                ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    100);
            } else {
                statusText.setText("Permisos OK - App lista");
            }
        }, 500);
    }
    
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 100) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                statusText.setText("Permisos concedidos");
            } else {
                statusText.setText("Permisos denegados");
            }
        }
    }
}