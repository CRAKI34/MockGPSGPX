package com.mockgps.gpx;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
        }

        Button start = findViewById(R.id.btnStart);
        Button stop = findViewById(R.id.btnStop);

        start.setOnClickListener(v -> {
            Intent i = new Intent(this, MockLocationService.class);
            i.putExtra("lat", 19.432608);
            i.putExtra("lon", -99.133209);
            i.putExtra("speed", 1.2f); // m/s
            if (Build.VERSION.SDK_INT >= 26)
                startForegroundService(i);
            else
                startService(i);
        });

        stop.setOnClickListener(v -> {
            stopService(new Intent(this, MockLocationService.class));
        });
    }
}