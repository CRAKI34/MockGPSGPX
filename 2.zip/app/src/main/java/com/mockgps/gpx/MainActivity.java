package com.mockgps.gpx;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText etLat, etLon;
    private Uri gpxUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etLat = findViewById(R.id.etLat);
        etLon = findViewById(R.id.etLon);

        Button btnSetFixed = findViewById(R.id.btnSetFixed);
        Button btnClear = findViewById(R.id.btnClear);
        Button btnSelectGPX = findViewById(R.id.btnSelectGPX);
        Button btnStartRoute = findViewById(R.id.btnStartRoute);

        btnSetFixed.setOnClickListener(v -> startFixed());
        btnClear.setOnClickListener(v -> stopService(new Intent(this, MockLocationService.class)));
        btnSelectGPX.setOnClickListener(v -> pickGPX());
        btnStartRoute.setOnClickListener(v -> startRoute());

        startActivity(new Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS));
    }

    private void startFixed() {
        Intent i = new Intent(this, MockLocationService.class);
        i.putExtra("mode", "fixed");
        i.putExtra("lat", Double.parseDouble(etLat.getText().toString()));
        i.putExtra("lon", Double.parseDouble(etLon.getText().toString()));
        startForegroundService(i);
    }

    private void startRoute() {
        if (gpxUri == null) {
            Toast.makeText(this, "Selecciona un GPX", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent i = new Intent(this, MockLocationService.class);
        i.putExtra("mode", "gpx");
        i.putExtra("gpx", gpxUri.toString());
        startForegroundService(i);
    }

    private void pickGPX() {
        gpxLauncher.launch("*/*");
    }

    private final ActivityResultLauncher<String> gpxLauncher =
            registerForActivityResult(new ActivityResultContracts.GetContent(),
                    uri -> gpxUri = uri);
}